﻿using System;

namespace YACESTest
{
	public class Transform2D
	{
		public Transform2D ()
		{
		}
	}
}

