﻿using System;

namespace YACES
{
	public class Render : GameComponent
	{
		public Render ()
		{
		}
	}
}

