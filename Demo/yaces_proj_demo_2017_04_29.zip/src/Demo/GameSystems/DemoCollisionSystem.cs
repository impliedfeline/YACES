﻿using System;
using Microsoft.Xna.Framework;

namespace YACES
{
	public class DemoCollisionSystem : GameSystem
	{
		public DemoCollisionSystem () : base ()
		{
		}

		public override void Run (GameInstance gameInstance, GameTime gameTime)
		{
		}
	}
}

